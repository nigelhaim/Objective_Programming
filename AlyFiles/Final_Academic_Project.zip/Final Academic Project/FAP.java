/*
 * ICS2606 - Computer Programming 2
 * Final Academic Project
 * Alyza Paige L. Ng - 1CSA
 * May 30, 2022
 * 2nd Term 2021-2022
 */

public class FAP
{	
	public static void main(String[] args)
	{
		//Login login = new Login();
		//login.startApp();
		Records records = new Records();
		records.startApp();
		//AddRecord addR = new AddRecord();
		//addR.startApp();
		//RemoveRecord removeR = new RemoveRecord();
		//removeR.startApp();
	}
}